This folder will be where you eventually move notes to be part of your own personal memex. See [the course website](https://shawngraham.github.io/hist1900/3.Technical_Help/2.Set%20Up%20Your%20Online%20Memex/).  Obsidian doesn't care which folder your notes are in, as it can always find them inside the main vault. But for your memex, items you move in here you will eventually push online.

> protip. You can find your note files on your machine by right-clicking a note in the left hand pane and selecting 'reveal in finder'. When we get to the point that you are putting materials online, you will need to be able to find this actual location on your machine.

