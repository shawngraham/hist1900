A short video that shows the basics of Obsidian (not by SG):
[https://www.youtube.com/watch?v=QgbLb6QCK88](https://www.youtube.com/watch?v=QgbLb6QCK88)

A video showing just how powerful Obsidian can be for your notetaking can be found at [' How to turn your notes into published articles and books using the Obsidian app with Eleanor Konik'](https://www.youtube.com/watch?v=nO5N_x2so0g).

A video tutorial about the Journey plugin, which you will use for your final piece of work here.
 [https://youtu.be/6k2Lp1pCZpY](https://youtu.be/6k2Lp1pCZpY)