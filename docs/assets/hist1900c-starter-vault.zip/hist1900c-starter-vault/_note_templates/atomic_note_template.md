---
Title: PUT THE TITLE OF NOTE HERE
date: {{date}}
type: literature
project:
---
tags:: 
projects::[[]]


-   One idea per note - but as complete as possible in your own words
-   Write as if you are writing for someone else. Use full sentences
-   Include sources in the note, but the note should be understood even if you don't know the context it was taken from. The note should **stand by itself**
-   Be precise, clear and brief.}

---
### Citational Information

Link to the originating literature note.

---

### Related Links

{Use this section to think about connections. Think about **how the newly created notes connect with your existing knowledge**. If you find some connections, connect the new notes with the older notes already in your system.To find these, ask:

-   How does this idea fit into what I already know?
-   What does this idea mean for some other idea that I already have?
-   Does this add to, contradict, or explain another idea that I already have?

You link to other notes by putting them in square brackets. Remember that Obsidian will auto search as you type for notes with those words. Once you've selected a note, you can add the ^ symbol to link to a subheading or block within a note, too.}