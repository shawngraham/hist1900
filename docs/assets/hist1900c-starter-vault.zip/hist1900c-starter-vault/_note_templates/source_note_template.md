---
Title: [use @full-cite-key]
date: {{date}}
type: reference
project:
---

tags::
projects:[[]]

### Reference 

Use the zotero integration: full reference command to add the bibliographic metadata. In the metadata block above, use the cite key (start typing @ and the surname you're after to get that correct) . Change the title of the note to the cite key, including the @ sign.


---

### Summary & Key Take Aways

*Here type up a 1-2 paragraph concise summary of the article. 

*If there are any key image you want to refer, you can include them here, drop them into the media folder, and then use the ![[]] format (just the filename).

--- 

### Links
Put any links to separate notes you have teased out here.