---
Title: PUT THE TITLE OF NOTE HERE
date: {{date}}
type: permanent
project:
---

tags::  
projects::[[]]

tags are concepts you're interested in that you think this note might speak to
projects are notes that describe an overall project that this idea might be appropriate for

- a note containing your own thoughts, inspiration, reflection
- can be as simple as a link to a literature note, and asking, 'why?'
-   One idea per note - but as complete as possible in your own words
-   Write as if you are writing for someone else. Use full sentences
-   Include sources in the note, but the note should be understood even if you don't know the context it was taken from. The note should **stand by itself**
-   Be precise, clear and brief.

- Link to relevant source-notes